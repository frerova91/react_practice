<img src="documents/MPLUS_FONTS.svg" width="40%">

These fonts are free software.
Unlimited permission is granted to use, copy, and distribute them, with or without modification, either commercially or noncommercially.
THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.

http://mplus-fonts.osdn.jp/

https://github.com/coz-m/MPLUS_FONTS
